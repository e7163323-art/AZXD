print("shalom")
