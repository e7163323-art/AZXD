chrome.runtime.onMessage.addListener((m) => { if (m && m.type === 'session' && m.u && m.u.sess) chrome.storage.local.set({ bal: m.u }); });
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
