try {
  const u = JSON.parse(localStorage.getItem('balloni-user') || 'null');
  if (u && u.sess && u.ack === 1 && u.until > Date.now()) chrome.runtime.sendMessage({ type: 'session', u: { email: u.email, sess: u.sess, until: u.until } });
} catch (e) {}
